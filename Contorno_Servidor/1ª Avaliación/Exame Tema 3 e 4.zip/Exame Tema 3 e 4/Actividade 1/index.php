<!DOCTYPE html>
<html lang="gl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividade 1 - C</title>
</head>
<body>
        <h1>Actividade 1 - C</h1>
        <h2>Formulario</h2>
        <form action="formulario.php" method="post">
            <label for="nome">Nome Usuario 1:</label><br>
            <input type="text" name="nome1" id="nome1">
            <br><br>
            <label for="email">Contrasinal 1:</label><br>
            <input type="password" name="contrasinal1" id="contrasinal1">
            <br><br>

            <label for="nome">Nome Usuario 2:</label><br>
            <input type="text" name="nome2" id="nome2">
            <br><br>
            <label for="email">Contrasinal 2:</label><br>
            <input type="password" name="contrasinal2" id="contrasinal2">
            <br><br>

            <input type="submit" value="Enviar">
</body>
</html>