<!DOCTYPE html>
<html lang="gl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividade 1 - D</title>
</head>
<body>
        <h1>Actividade 1 - D</h1>
        <h2>Formulario -Inicio Sesión: </h2>
        <form action="formulario2.php" method="post">
            <label for="nome">Nome: </label><br>
            <input type="text" name="nome" id="nome">
            <br><br>
            <label for="password">Contrasinal: </label><br>
            <input type="password" name="contrasinal" id="contrasinal">
            <br><br>
            <input type="submit" value="Iniciar Sesión">
    
</body>
</html>