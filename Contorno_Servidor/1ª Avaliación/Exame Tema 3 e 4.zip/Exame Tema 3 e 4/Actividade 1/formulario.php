<?php
  
        
    $usuario1 = $_POST['nome1'];   
    $usuario2 = $_POST['nome2'];   
    $contrasinal1 = $_POST['contrasinal1'];   
    $contrasinal2 = $_POST['contrasinal2'];   


    echo "<b>Usuario1:</b><br> Nome: $usuario1<br>";
    echo "Contrasinal: $contrasinal1<br><br>";

    echo "<b>Usuario2:</b><br> Nome: $usuario2<br>"; 
    echo "Contrasinal: $contrasinal2<br>";


?>