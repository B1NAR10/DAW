$(document).ready(function() {
	usuario = 1;
	nomeClase = "";
	nomeLogo = "";
	dataCodigoLogo = -1;
	codigoClase = -1;

	function CargarClases(){
		// Cargamos as Clases 
		$.getJSON("servidor/cargarClasesUsuario.php", {codigo:usuario}, function(result){

			// Recorrer Array Clases (Categorías).
			$.each(result, function(i, datosClase){
				
				let stricona = `<div class="icona"><img class='icona' src='imaxes/iconas/${datosClase.idClase}.png' data-codigo ='${datosClase.idClase}' data-clase = '${datosClase.nome}'></div>`

				solucion.innerHTML += 
				`<div class="clase">${stricona}<div class="texto"><span class="texto">${datosClase.nome}</span></div><div class="numero"><span class="numero">${datosClase.solucionadas}/${datosClase.numero}</span></div></div>`

			});

		
			$('img.icona').on('click', function(){
				operacions.innerHTML += `<button id = "botonInicio">Inicio</button>`;
				$('#botonInicio').on('click', function(){
					solucion.innerHTML = "";
					$('#botonInicio').remove();
					CargarClases();
				})

				// Cargamos LOGOS (Miniaturas)
				let etiquetaImg = $(this);
				codigoClase = etiquetaImg.attr('data-codigo');
				nomeClase = etiquetaImg.attr('data-clase');

			    CargarMiniaturas();
			
			});


		});
	}

	function CargarMiniaturas(){
		$.getJSON("servidor/cargarMiniaturas.php", {codigo:codigoClase }, function(result){
			console.log(result);
			solucion.innerHTML = "";
			$.each(result, function(i, datosMiniatura){
				solucion.innerHTML +=`<img class = "miniatura" src = "imaxes/${nomeClase}/${datosMiniatura.idImaxe}.png" data-codigo = "${datosMiniatura.idImaxe}" >`;
			});	
			$('img.miniatura').on('click', function(){
				dataCodigoLogo = $(this).attr('data-codigo');
				pantallaLogo();
			});		
			
		});
	}	

	function pantallaLogo(){
		operacions.innerHTML += `<button id = "clases">${nomeClase}</button>`;
		$('#clases').on('click', function(){
			solucion.innerHTML = "";
			$('#clases').remove();
			CargarMiniaturas();
		});

		// Pedimos Información Logo: entrega o nome do logo e a se está solucionado.
		$.getJSON("servidor/cargarLogo.php", {codigo:dataCodigoLogo }, function(result){
			console.log(result);
			nomeLogo = result.nome.toUpperCase();

			solucion.innerHTML = "";
			solucion.innerHTML += `<div class = 'logo'> <img class = 'logo' src="imaxes/${nomeClase}/${dataCodigoLogo}.png"> </div>`; 
			solucion.innerHTML += `<div class="ocos">`;

			for(let i = 0; i < nomeLogo.length; i++){

					if(nomeLogo[i] == " "){
						solucion.innerHTML += `<br/>`;
					}else{
						let letra = "" 
						if(result.resolta == 1){
							letra = nomeLogo[i];
						}else{
							letra = "&nbsp;";
						}	
							solucion.innerHTML += `<div class="oco">
												<span class="letra">${letra}</span>
											</div>`;
					}						
			
			}
			solucion.innerHTML += `</div>`;

			
			
			if(result.resolta == 0){
				let LogoSenEspazos = "";
				for(let i = 0; i < nomeLogo.length; i++){
					if(nomeLogo[i] != " "){
						LogoSenEspazos += nomeLogo[i];
					}
				}	

				let numLetrasXerar = 16 - LogoSenEspazos.length;

				let LetrasXeradas = ""

				for(let i = 0; i < numLetrasXerar; i++){
					let codigoLetraAleatorio = Math.ceil(Math.random()* (90 - 65 + 1)) + 65;
					let letraAleatoria = String.fromCharCode(codigoLetraAleatorio);
					LetrasXeradas += letraAleatoria;

				}

				let totalLetras = LetrasXeradas + LogoSenEspazos;

				totalLetras = totalLetras.split("").sort().join(""); // split = divide a string en un array. sort = ordena o array. join = une o array en unha string.

				solucion.innerHTML += `<div class="letras">`;

				for(let i = 0; i < totalLetras.length; i++){

					if(totalLetras[i] != " "){
						solucion.innerHTML += `<div class="letra">
											<span class="letra">${totalLetras[i]}</span>
											</div>`;
					}
				}	

				solucion.innerHTML += `</div>`;
			}
			
		

		});	

		$('#botonInicio').on('click', function(){
			solucion.innerHTML = "";
			$('#botonInicio').remove();
			$('#clases').remove();
			CargarClases();
		})

		
	}

	CargarClases();

	// Cargamos Datos de Usuario.
	$.getJSON("servidor/cargarDatosUsuario.php", {codigo:usuario}, function(result){
		console.log(result);
		let strnome =	`<div class="nome">
							<span class="texto">${result.nome}</span>
						</div>`
		let strpuntos =	`<div class="puntos">	
							<span class="numero">${result.puntos}</span>
						</div>`
		operacions.innerHTML = strnome + strpuntos;				

	});




});



 